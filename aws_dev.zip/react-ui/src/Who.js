import MenuNavAndFooter from "./MenuNavAndFooter";

const Who = () => {
    return (
        <MenuNavAndFooter>

            <div className="container-fluid container-login-scroll">
                <div className="row login-vertical-center min-vh-100">
                    <div className="col"></div>
                    <div className="col-xxl-4 col-xl-4 col-lg-5 col-md-6 col-sm-8 col-xs-10">
                        <div className="card shadow-lg rounded-lg bg-transparent">
                            <div className="card-body">
                                <div className="container-fluid">
                                    <div className="row">
                                        <div className="col">

                                            <h1>La locale du GRACQ de WB</h1>

                                            <p>
                                                Nous sommes la locale du GRACQ de WB.
                                            </p>

                                            <p>
                                                Pour savoir ce qu'est le GRACQ, ça se passe ici.
                                            </p>

                                            <p>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col"></div>
                </div>
            </div>

        </MenuNavAndFooter>
    )
}

export default Who