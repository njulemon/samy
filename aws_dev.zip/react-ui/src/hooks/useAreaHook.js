import {useEffect, useState} from "react";
import {urlServer} from "../def/Definitions";
import axios from "axios";
import {useAppDispatch, useAppSelector} from "../app/hooks";
import {setCommunesGeoJson} from "../app/States";
import * as localforage from "localforage";

export const useAreaHook = () => {
    // cache + fetch communes from the DB.

    // based on redux states
    const dispatch = useAppDispatch()
    const communesGeoJson = useAppSelector((state) => state.states.communesGeoJson)
    const [communesGeoJsonRaw, setCommunesGeoJsonRaw] = useState(null)

    useEffect(() => {
        if (!communesGeoJson) {
            localforage.getItem('communesGeoJson', (err, value) => {
                if (value === null) {
                    fetchFeatureSelection()
                } else {
                    setCommunesGeoJsonRaw(value)
                }
            })
        }
    }, [])

    useEffect(() => {

        const addActive = async () => {
            const featuresCollectionCopy = JSON.parse(JSON.stringify(communesGeoJsonRaw))

            const activeRequest = await axios.get(urlServer + '/api/area/active/', {withCredentials: true})

            const listActive = activeRequest.data.map(row => row.name)

            console.log(listActive)

            featuresCollectionCopy.features?.forEach((row, idx) => {
                    const name = row["properties"]["name"]
                    // debugger
                    featuresCollectionCopy['features'][idx]["properties"]["active"] = !!listActive.includes(name);
                }
            )

            console.log(featuresCollectionCopy)

            dispatch(setCommunesGeoJson(featuresCollectionCopy))
        }

        if (communesGeoJsonRaw) {
            addActive()
        }

    }, [communesGeoJsonRaw])

    const fetchFeatureSelection = () => {

        const request = urlServer + `/api/area/`

        axios.get(request, {withCredentials: true})
            .then(result => {
                const data = result.data
                const features = data.map(row => row.boundary)
                const featuresCollection = {"type": "FeatureCollection", "features": features}
                setCommunesGeoJsonRaw(featuresCollection)
                localforage.setItem('communesGeoJson', featuresCollection)
            })
    }

    return {communesGeoJson, fetchFeatureSelection}
}