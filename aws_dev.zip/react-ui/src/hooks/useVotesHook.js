export const useVotesHook = () => {
    // TODO
    return []
}