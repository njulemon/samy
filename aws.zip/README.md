# SAMY APP

## Introduction
Samy-app is a geo-tagging web application made mainly for cyclists. 

## Architecture
Samy-app is based on React to generate the UI and Django REST framework
to make the API. It is containerised in a docker container which
integrates NGINX to serve js code (REACT) & communicate with API
through WGSI. 


## File structure


## How to use it
